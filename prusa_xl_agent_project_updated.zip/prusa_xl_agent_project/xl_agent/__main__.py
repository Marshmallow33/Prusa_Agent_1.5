"""Chat with the agent:  python -m xl_agent [--gcode file.gcode]"""
import argparse
import os

from . import tools
from .agent import Agent
from .llm import load_llm


def _load_env():
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass


def main():
    _load_env()
    ap = argparse.ArgumentParser()
    ap.add_argument("--gcode", help="G-code file to discuss")
    ap.add_argument("-v", "--verbose", action="store_true", help="show tool calls")
    args = ap.parse_args()

    llm = load_llm()
    tools.confirm_start = lambda summary: input(f"\n{summary}\nType PRINT to start: ").strip() == "PRINT"
    agent = Agent(llm, log=print if args.verbose else (lambda s: None))
    print(f"Prusa XL assistant ({llm.name}). Type 'quit' to exit.")
    if os.getenv("PRUSALINK_HOST"):
        print(f"PrusaLink: {os.getenv('PRUSALINK_HOST')} (can upload; printing needs your typed PRINT)")
    first = f"I want to print {args.gcode}. Check it and get me ready." if args.gcode else None

    while True:
        try:
            text = first or input("\nyou> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        first = None
        if text.lower() in {"quit", "exit"}:
            break
        if text:
            print("\nagent>", agent.ask(text))


if __name__ == "__main__":
    main()
