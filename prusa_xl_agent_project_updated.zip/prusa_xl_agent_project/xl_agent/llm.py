"""LLM providers. All expose chat(system, messages) -> str.

Messages are [{"role": "user"|"assistant", "content": str}].
Swap providers with LLM_PROVIDER=ollama | gemini | openai_compat | mock
(see .env.example). Nothing here uses vendor SDKs, only `requests`.
"""
from __future__ import annotations

import os
from typing import Dict, List, Protocol

import requests

Message = Dict[str, str]


class LLM(Protocol):
    name: str

    def chat(self, system: str, messages: List[Message]) -> str: ...


class OllamaLLM:
    """Local model, e.g. `ollama pull phi3:mini`. Server runs on localhost:11434."""

    def __init__(self, model: str = "phi3:mini", host: str = "http://localhost:11434"):
        self.model, self.host = model, host.rstrip("/")
        self.name = f"ollama/{model}"

    def chat(self, system, messages):
        r = requests.post(
            f"{self.host}/api/chat",
            json={
                "model": self.model,
                "stream": False,
                "options": {"temperature": 0.1},
                "messages": [{"role": "system", "content": system}, *messages],
            },
            timeout=300,
        )
        r.raise_for_status()
        return r.json()["message"]["content"]


class GeminiLLM:
    """Google Gemini via REST (free AI Studio keys work)."""

    def __init__(self, api_key: str, model: str = "gemini-2.5-flash"):
        self.api_key, self.model = api_key, model
        self.name = f"gemini/{model}"

    def chat(self, system, messages):
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        body = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [
                {"role": "model" if m["role"] == "assistant" else "user",
                 "parts": [{"text": m["content"]}]}
                for m in messages
            ],
            "generationConfig": {"temperature": 0.1},
        }
        r = requests.post(url, json=body, headers={"x-goog-api-key": self.api_key}, timeout=120)
        r.raise_for_status()
        parts = r.json()["candidates"][0]["content"]["parts"]
        return "".join(p.get("text", "") for p in parts)


class OpenAICompatLLM:
    """Any OpenAI-style /chat/completions endpoint.

    Put the IntelliMake-provided base URL / key / model here once you have
    them. If their API is not OpenAI-style, only this class needs changing.
    """

    def __init__(self, base_url: str, api_key: str, model: str):
        self.base_url, self.api_key, self.model = base_url.rstrip("/"), api_key, model
        self.name = f"openai_compat/{model}"

    def chat(self, system, messages):
        r = requests.post(
            f"{self.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={
                "model": self.model,
                "temperature": 0.1,
                "messages": [{"role": "system", "content": system}, *messages],
            },
            timeout=120,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]


def load_llm() -> LLM:
    provider = os.getenv("LLM_PROVIDER", "ollama").lower()
    if provider == "ollama":
        return OllamaLLM(os.getenv("OLLAMA_MODEL", "phi3:mini"),
                         os.getenv("OLLAMA_HOST", "http://localhost:11434"))
    if provider == "gemini":
        key = os.getenv("GEMINI_API_KEY")
        if not key:
            raise SystemExit("Set GEMINI_API_KEY (see .env.example)")
        return GeminiLLM(key, os.getenv("GEMINI_MODEL", "gemini-2.5-flash"))
    if provider == "openai_compat":
        try:
            return OpenAICompatLLM(os.environ["LLM_BASE_URL"], os.environ["LLM_API_KEY"],
                                   os.environ["LLM_MODEL"])
        except KeyError as e:
            raise SystemExit(f"Set {e.args[0]} (see .env.example)")
    raise SystemExit(f"Unknown LLM_PROVIDER '{provider}'")
