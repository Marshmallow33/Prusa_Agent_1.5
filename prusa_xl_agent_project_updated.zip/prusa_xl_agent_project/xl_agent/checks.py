"""
Prusa XL Calibration / Pre-Print Agent MVP
------------------------------------------
Features:
1. Analyze PrusaSlicer G-code.
2. Run a Prusa XL readiness checklist.
3. Optionally read live printer information/status from PrusaLink.
4. Produce a PASS/WARN/FAIL readiness report.

Safety:
- This MVP is READ-ONLY with respect to PrusaLink.
- It does NOT start prints, move axes, or command heaters.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import requests
    from requests.auth import HTTPDigestAuth
except ImportError:
    requests = None
    HTTPDigestAuth = None


# ---------------------------------------------------------------------
# MATERIAL KNOWLEDGE BASE
# Conservative broad ranges for warning purposes only.
# Prefer the exact PrusaSlicer filament profile for the real print.
# ---------------------------------------------------------------------

MATERIALS: Dict[str, Dict[str, Any]] = {
    "PLA": {
        "nozzle_range": (190, 230),
        "bed_range": (45, 70),
        "moisture_sensitive": False,
        "abrasive": False,
        "enclosure_helpful": False,
    },
    "PETG": {
        "nozzle_range": (220, 260),
        "bed_range": (70, 95),
        "moisture_sensitive": True,
        "abrasive": False,
        "enclosure_helpful": False,
    },
    "ASA": {
        "nozzle_range": (240, 285),
        "bed_range": (90, 120),
        "moisture_sensitive": True,
        "abrasive": False,
        "enclosure_helpful": True,
    },
    "ABS": {
        "nozzle_range": (230, 270),
        "bed_range": (90, 120),
        "moisture_sensitive": True,
        "abrasive": False,
        "enclosure_helpful": True,
    },
    "TPU": {
        "nozzle_range": (210, 260),
        "bed_range": (0, 70),
        "moisture_sensitive": True,
        "abrasive": False,
        "enclosure_helpful": False,
    },
    "PA": {
        "nozzle_range": (240, 300),
        "bed_range": (70, 120),
        "moisture_sensitive": True,
        "abrasive": False,
        "enclosure_helpful": True,
    },
    "NYLON": {
        "nozzle_range": (240, 300),
        "bed_range": (70, 120),
        "moisture_sensitive": True,
        "abrasive": False,
        "enclosure_helpful": True,
    },
    "PC": {
        "nozzle_range": (250, 310),
        "bed_range": (90, 120),
        "moisture_sensitive": True,
        "abrasive": False,
        "enclosure_helpful": True,
    },
    "PVA": {
        "nozzle_range": (180, 230),
        "bed_range": (45, 70),
        "moisture_sensitive": True,
        "abrasive": False,
        "enclosure_helpful": False,
    },
}

ABRASIVE_TOKENS = (
    "CF", "CARBON", "GF", "GLASS", "GLOW", "WOOD", "METAL", "FILLED"
)


# ---------------------------------------------------------------------
# DATA OBJECTS
# ---------------------------------------------------------------------

@dataclass
class Finding:
    level: str           # PASS / WARN / FAIL / INFO
    category: str
    message: str


@dataclass
class GCodeAnalysis:
    file: str
    slicer: Optional[str] = None
    printer_model: Optional[str] = None
    nozzle_diameters: List[float] = field(default_factory=list)
    filament_types: List[str] = field(default_factory=list)
    nozzle_targets: List[float] = field(default_factory=list)
    bed_targets: List[float] = field(default_factory=list)
    tools_used: List[int] = field(default_factory=list)
    support_enabled: Optional[bool] = None
    support_detected_in_gcode: bool = False
    support_extruder: Optional[str] = None
    support_interface_extruder: Optional[str] = None
    wipe_tower: Optional[bool] = None
    estimated_print_time: Optional[str] = None
    filament_used: Optional[str] = None
    config: Dict[str, str] = field(default_factory=dict)


@dataclass
class ManualChecklist:
    nozzle_clean: bool
    sheet_clean: bool
    sheet_seated: bool
    nothing_under_sheet: bool
    build_area_clear: bool
    fans_clear: bool
    tool_docks_clear: bool
    filament_loaded_correctly: bool
    enough_filament: bool
    filament_dry: bool
    selftest_passed: bool
    loadcell_ok: bool
    phase_stepping_ok: bool
    tool_offset_ok: bool
    belts_look_ok: bool
    nozzle_not_damaged: bool
    hardened_nozzle_installed: bool
    enclosure_available: bool


# ---------------------------------------------------------------------
# UTILITIES
# ---------------------------------------------------------------------

def parse_bool(value: Optional[str]) -> Optional[bool]:
    if value is None:
        return None
    v = str(value).strip().lower()
    if v in {"1", "true", "yes", "on"}:
        return True
    if v in {"0", "false", "no", "off"}:
        return False
    return None


def split_multi(value: Optional[str]) -> List[str]:
    if not value:
        return []
    # PrusaSlicer commonly uses semicolon separated multi-extruder values.
    return [p.strip() for p in re.split(r"[;,]", value) if p.strip()]


def floats_from_value(value: Optional[str]) -> List[float]:
    out = []
    for item in split_multi(value):
        try:
            out.append(float(item))
        except ValueError:
            pass
    return out


def unique_keep_order(items):
    seen = set()
    result = []
    for x in items:
        if x not in seen:
            seen.add(x)
            result.append(x)
    return result


def yes_no(prompt: str, default: Optional[bool] = None) -> bool:
    suffix = " [Y/n]: " if default is True else " [y/N]: " if default is False else " [y/n]: "
    while True:
        value = input(prompt + suffix).strip().lower()
        if not value and default is not None:
            return default
        if value in {"y", "yes"}:
            return True
        if value in {"n", "no"}:
            return False
        print("Please enter y or n.")


# ---------------------------------------------------------------------
# G-CODE ANALYZER
# ---------------------------------------------------------------------

CONFIG_BEGIN_MARKERS = (
    "; prusaslicer_config = begin",
    "; prusaslicer_config = begin",
)
CONFIG_END_MARKERS = (
    "; prusaslicer_config = end",
    "; prusaslicer_config = end",
)


def analyze_gcode(path: str) -> GCodeAnalysis:
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(file_path)

    analysis = GCodeAnalysis(file=str(file_path.resolve()))
    config: Dict[str, str] = {}

    nozzle_targets = []
    bed_targets = []
    tools = []
    support_detected = False
    in_config = False

    # Read line-by-line so very large G-code files do not need to be held in RAM.
    with file_path.open("r", encoding="utf-8", errors="ignore") as f:
        for raw in f:
            line = raw.strip()
            low = line.lower()

            if low.startswith("; generated by"):
                analysis.slicer = line.lstrip(";").strip()

            if any(marker in low for marker in CONFIG_BEGIN_MARKERS):
                in_config = True
                continue
            if any(marker in low for marker in CONFIG_END_MARKERS):
                in_config = False
                continue

            # PrusaSlicer config comments are often: "; key = value"
            if line.startswith(";"):
                m = re.match(r";\s*([A-Za-z0-9_]+)\s*=\s*(.*)$", line)
                if m:
                    key, value = m.group(1), m.group(2).strip()
                    # Save config comments both inside and outside the block.
                    if in_config or key in {
                        "printer_model", "nozzle_diameter", "filament_type",
                        "support_material", "support_material_extruder",
                        "support_material_interface_extruder", "wipe_tower",
                        "temperature", "first_layer_temperature",
                        "bed_temperature", "first_layer_bed_temperature"
                    }:
                        config[key] = value

                # Common PrusaSlicer summary comments.
                if "estimated printing time" in low and "=" in line:
                    analysis.estimated_print_time = line.split("=", 1)[1].strip()
                if "filament used" in low and "=" in line and analysis.filament_used is None:
                    analysis.filament_used = line.split("=", 1)[1].strip()

                # Support path markers differ by version/flavor; detect several.
                if (
                    "type:support" in low
                    or "type: support" in low
                    or "generated support material" in low
                    or "support material interface" in low
                ):
                    support_detected = True

            # Target hotend commands: M104 = set; M109 = set/wait.
            if re.match(r"^M10[49]\b", line, re.I):
                m = re.search(r"\bS(-?\d+(?:\.\d+)?)", line, re.I)
                if m:
                    temp = float(m.group(1))
                    if temp > 0:
                        nozzle_targets.append(temp)

            # Bed commands: M140 = set; M190 = set/wait.
            if re.match(r"^M1(?:40|90)\b", line, re.I):
                m = re.search(r"\bS(-?\d+(?:\.\d+)?)", line, re.I)
                if m:
                    temp = float(m.group(1))
                    if temp > 0:
                        bed_targets.append(temp)

            # Tool selection T0, T1, ...
            m = re.match(r"^T(\d+)\b", line, re.I)
            if m:
                tools.append(int(m.group(1)))

    analysis.config = config
    analysis.support_detected_in_gcode = support_detected
    analysis.nozzle_targets = unique_keep_order(nozzle_targets)
    analysis.bed_targets = unique_keep_order(bed_targets)
    analysis.tools_used = unique_keep_order(tools)

    analysis.printer_model = config.get("printer_model")

    analysis.nozzle_diameters = floats_from_value(config.get("nozzle_diameter"))
    analysis.filament_types = split_multi(config.get("filament_type"))

    analysis.support_enabled = parse_bool(config.get("support_material"))
    analysis.support_extruder = config.get("support_material_extruder")
    analysis.support_interface_extruder = config.get("support_material_interface_extruder")
    analysis.wipe_tower = parse_bool(config.get("wipe_tower"))

    return analysis


# ---------------------------------------------------------------------
# PRUSALINK READ-ONLY CLIENT
# ---------------------------------------------------------------------

class PrusaLinkClient:
    """Read-only PrusaLink client using HTTP Digest authentication."""

    def __init__(self, host: str, username: str, password: str, timeout: float = 5.0):
        if requests is None:
            raise RuntimeError("The 'requests' package is not installed. Run: pip install requests")
        if not host.startswith(("http://", "https://")):
            host = "http://" + host
        self.host = host.rstrip("/")
        self.auth = HTTPDigestAuth(username, password)
        self.timeout = timeout

    def _get(self, endpoint: str) -> Dict[str, Any]:
        url = self.host + endpoint
        r = requests.get(url, auth=self.auth, timeout=self.timeout)
        r.raise_for_status()
        if not r.content:
            return {}
        return r.json()

    def version(self) -> Dict[str, Any]:
        return self._get("/api/version")

    def info(self) -> Dict[str, Any]:
        return self._get("/api/v1/info")

    def status(self) -> Dict[str, Any]:
        return self._get("/api/v1/status")

    def snapshot(self) -> Dict[str, Any]:
        result = {}
        for name, fn in [
            ("version", self.version),
            ("info", self.info),
            ("status", self.status),
        ]:
            try:
                result[name] = fn()
            except Exception as exc:
                result[name] = {"error": f"{type(exc).__name__}: {exc}"}
        return result


# ---------------------------------------------------------------------
# MANUAL CHECKLIST
# ---------------------------------------------------------------------

def collect_checklist() -> ManualChecklist:
    print("\n=== PHYSICAL PRUSA XL INSPECTION ===")
    print("Answer based on what you can physically verify right now.\n")

    return ManualChecklist(
        nozzle_clean=yes_no("Nozzle exterior is clean (no blob/residue)?"),
        sheet_clean=yes_no("Print sheet is clean and free of grease/debris?"),
        sheet_seated=yes_no("Print sheet is seated flat and correctly?"),
        nothing_under_sheet=yes_no("Nothing is trapped underneath the print sheet?"),
        build_area_clear=yes_no("Build volume is clear of tools/old parts/obstructions?"),
        fans_clear=yes_no("Hotend/print fans look clear and unobstructed?"),
        tool_docks_clear=yes_no("XL tool docks and toolchanger path are clear?"),
        filament_loaded_correctly=yes_no("Correct filament is loaded into the required tool(s)?"),
        enough_filament=yes_no("There appears to be enough filament for the job?"),
        filament_dry=yes_no("Filament condition is dry/acceptable?"),
        selftest_passed=yes_no("Printer self-test has passed?"),
        loadcell_ok=yes_no("Loadcell calibration/test is known to be good?"),
        phase_stepping_ok=yes_no("Phase Stepping calibration is known to be good?"),
        tool_offset_ok=yes_no("Tool-offset calibration is good for the tools being used?"),
        belts_look_ok=yes_no("Belts/mechanics look normal (no obvious looseness/damage)?"),
        nozzle_not_damaged=yes_no("Nozzle appears undamaged and correctly installed?"),
        hardened_nozzle_installed=yes_no("Wear-resistant/hardened nozzle is installed?", default=False),
        enclosure_available=yes_no("Enclosure is available/in use?", default=False),
    )


# ---------------------------------------------------------------------
# DECISION ENGINE
# ---------------------------------------------------------------------

def normalize_material(raw: str) -> str:
    u = raw.upper().strip()
    if "PLA" in u:
        return "PLA"
    if "PETG" in u or "PET-G" in u:
        return "PETG"
    if "ASA" in u:
        return "ASA"
    if "ABS" in u:
        return "ABS"
    if "TPU" in u or "FLEX" in u:
        return "TPU"
    if "NYLON" in u:
        return "NYLON"
    if re.search(r"\bPA\d*\b", u):
        return "PA"
    if re.search(r"\bPC\b", u):
        return "PC"
    if "PVA" in u:
        return "PVA"
    return u


def is_abrasive(material: str) -> bool:
    u = material.upper()
    return any(token in u for token in ABRASIVE_TOKENS)


def evaluate(
    gcode: Optional[GCodeAnalysis],
    checklist: ManualChecklist,
    live: Optional[Dict[str, Any]] = None,
) -> List[Finding]:
    out: List[Finding] = []

    # ---- Physical critical checks
    critical_map = [
        ("Nozzle", checklist.nozzle_clean, "Nozzle exterior is clean.",
         "Nozzle has residue/blob contamination; clean it before calibration/printing."),
        ("Build plate", checklist.sheet_clean, "Print sheet is clean.",
         "Print sheet is dirty/greasy; clean it before printing."),
        ("Build plate", checklist.sheet_seated, "Print sheet is seated correctly.",
         "Print sheet is not confirmed seated correctly."),
        ("Build plate", checklist.nothing_under_sheet, "Nothing is under the print sheet.",
         "Something may be trapped beneath the sheet; remove it before leveling/printing."),
        ("Safety", checklist.build_area_clear, "Build volume is clear.",
         "Build area is obstructed."),
        ("Toolchanger", checklist.tool_docks_clear, "Tool docks/path are clear.",
         "Toolchanger/dock path is not clear."),
        ("Material", checklist.filament_loaded_correctly, "Correct filament is loaded.",
         "Correct filament/tool assignment is not confirmed."),
        ("Calibration", checklist.selftest_passed, "Self-test is confirmed.",
         "Printer self-test is not confirmed passing."),
        ("Calibration", checklist.loadcell_ok, "Loadcell status is confirmed good.",
         "Loadcell calibration/test is not confirmed."),
        ("Hardware", checklist.nozzle_not_damaged, "Nozzle condition looks good.",
         "Nozzle condition/installation is not confirmed."),
    ]

    for cat, ok, good, bad in critical_map:
        out.append(Finding("PASS" if ok else "FAIL", cat, good if ok else bad))

    # ---- Warning-level physical checks
    warning_map = [
        ("Cooling", checklist.fans_clear, "Fans look clear.", "Fans may be obstructed/dirty."),
        ("Material", checklist.enough_filament, "Enough filament is available.", "Filament quantity may be insufficient."),
        ("Material", checklist.filament_dry, "Filament condition is acceptable.", "Filament may be wet; moisture can cause poor extrusion/finish."),
        ("Calibration", checklist.phase_stepping_ok, "Phase Stepping is confirmed.", "Phase Stepping is not confirmed."),
        ("Calibration", checklist.tool_offset_ok, "Tool offsets are confirmed.", "Tool-offset calibration is not confirmed."),
        ("Mechanics", checklist.belts_look_ok, "Belts/mechanics look normal.", "Belts/mechanics should be inspected."),
    ]
    for cat, ok, good, bad in warning_map:
        out.append(Finding("PASS" if ok else "WARN", cat, good if ok else bad))

    if gcode:
        # Printer profile sanity
        if gcode.printer_model:
            if "XL" in gcode.printer_model.upper():
                out.append(Finding("PASS", "G-code", f"Printer model reports: {gcode.printer_model}"))
            else:
                out.append(Finding("WARN", "G-code",
                                   f"G-code printer model is '{gcode.printer_model}', not obviously a Prusa XL profile."))
        else:
            out.append(Finding("INFO", "G-code", "Printer model was not found in the G-code comments."))

        # Nozzle diameter
        if gcode.nozzle_diameters:
            out.append(Finding("INFO", "G-code",
                               "Configured nozzle diameter(s): " +
                               ", ".join(f"{x:.2f} mm" for x in gcode.nozzle_diameters)))
        else:
            out.append(Finding("WARN", "G-code", "Nozzle diameter was not found in PrusaSlicer configuration comments."))

        # Supports
        if gcode.support_enabled is True:
            out.append(Finding("PASS", "Supports", "PrusaSlicer support_material is enabled."))
        elif gcode.support_detected_in_gcode:
            out.append(Finding("PASS", "Supports", "Support extrusion markers were detected in the G-code."))
        elif gcode.support_enabled is False:
            out.append(Finding("INFO", "Supports", "Supports are disabled in the sliced G-code. Verify the model does not need them."))
        else:
            out.append(Finding("INFO", "Supports", "Support setting could not be determined conclusively."))

        # Multi-tool support assignment
        if len(gcode.tools_used) > 1:
            out.append(Finding("INFO", "Toolchanger",
                               f"Multiple tools are used: {', '.join('T'+str(t) for t in gcode.tools_used)}."))
            if not checklist.tool_offset_ok:
                out.append(Finding("FAIL", "Toolchanger",
                                   "Multi-tool print detected but tool-offset calibration is not confirmed."))
            if gcode.wipe_tower is False:
                out.append(Finding("INFO", "Toolchanger",
                                   "Wipe tower is disabled. This can be intentional on XL; verify it matches the selected material strategy."))

        if gcode.support_extruder:
            out.append(Finding("INFO", "Supports", f"Support extruder setting: {gcode.support_extruder}"))
        if gcode.support_interface_extruder:
            out.append(Finding("INFO", "Supports", f"Support interface extruder setting: {gcode.support_interface_extruder}"))

        # Material / temps
        mats = [m for m in gcode.filament_types if m]
        if mats:
            out.append(Finding("INFO", "Material", "Filament profile(s): " + ", ".join(mats)))

        for raw_material in mats:
            material = normalize_material(raw_material)
            info = MATERIALS.get(material)
            if info and info["moisture_sensitive"] and not checklist.filament_dry:
                out.append(Finding("WARN", "Material",
                                   f"{raw_material} is moisture-sensitive and filament dryness is not confirmed."))
            if is_abrasive(raw_material) and not checklist.hardened_nozzle_installed:
                out.append(Finding("FAIL", "Nozzle",
                                   f"{raw_material} appears abrasive, but a wear-resistant nozzle is not confirmed."))

        if gcode.nozzle_targets:
            out.append(Finding("INFO", "Temperature",
                               "Hotend target(s) in G-code: " +
                               ", ".join(f"{x:g}°C" for x in gcode.nozzle_targets)))
        if gcode.bed_targets:
            out.append(Finding("INFO", "Temperature",
                               "Bed target(s) in G-code: " +
                               ", ".join(f"{x:g}°C" for x in gcode.bed_targets)))

        # Broad range checks against detected material; profile remains authoritative.
        if mats:
            recognized = [normalize_material(x) for x in mats]
            known = [MATERIALS[m] for m in recognized if m in MATERIALS]
            if len(known) == 1:
                k = known[0]
                if gcode.nozzle_targets:
                    unusual = [t for t in gcode.nozzle_targets
                               if not (k["nozzle_range"][0] <= t <= k["nozzle_range"][1])]
                    if unusual:
                        out.append(Finding(
                            "WARN", "Temperature",
                            f"Some hotend targets ({unusual}) are outside this agent's broad reference range "
                            f"{k['nozzle_range']}°C. Confirm against your exact PrusaSlicer filament profile."
                        ))
                if gcode.bed_targets:
                    unusual = [t for t in gcode.bed_targets
                               if not (k["bed_range"][0] <= t <= k["bed_range"][1])]
                    if unusual:
                        out.append(Finding(
                            "WARN", "Temperature",
                            f"Some bed targets ({unusual}) are outside this agent's broad reference range "
                            f"{k['bed_range']}°C. Confirm against your exact PrusaSlicer filament profile."
                        ))

    if live:
        errors = []
        for key, value in live.items():
            if isinstance(value, dict) and "error" in value:
                errors.append(f"{key}: {value['error']}")
        if errors:
            out.append(Finding("WARN", "PrusaLink", "Could not read all live endpoints: " + " | ".join(errors)))
        else:
            out.append(Finding("PASS", "PrusaLink", "PrusaLink responded to version/info/status read-only requests."))

        status = live.get("status")
        if isinstance(status, dict) and "printer" in status:
            printer = status["printer"]
            out.append(Finding("INFO", "PrusaLink", f"Live printer status: {json.dumps(printer, ensure_ascii=False)}"))

    return out


def overall_status(findings: List[Finding]) -> str:
    if any(f.level == "FAIL" for f in findings):
        return "NOT READY"
    if any(f.level == "WARN" for f in findings):
        return "READY WITH WARNINGS"
    return "READY"


def print_gcode_summary(a: GCodeAnalysis):
    print("\n=== G-CODE ANALYSIS ===")
    print(f"File: {a.file}")
    print(f"Slicer: {a.slicer or 'Unknown'}")
    print(f"Printer model: {a.printer_model or 'Unknown'}")
    print("Nozzle diameter(s):", ", ".join(map(str, a.nozzle_diameters)) or "Unknown")
    print("Filament type(s):", ", ".join(a.filament_types) or "Unknown")
    print("Tools used:", ", ".join("T"+str(t) for t in a.tools_used) or "Not detected")
    print("Hotend targets:", ", ".join(f"{x:g}°C" for x in a.nozzle_targets) or "Not detected")
    print("Bed targets:", ", ".join(f"{x:g}°C" for x in a.bed_targets) or "Not detected")
    print(f"Support setting: {a.support_enabled}")
    print(f"Support paths detected: {a.support_detected_in_gcode}")
    print(f"Support extruder: {a.support_extruder or 'Unknown'}")
    print(f"Support interface extruder: {a.support_interface_extruder or 'Unknown'}")
    print(f"Wipe tower: {a.wipe_tower}")
    if a.estimated_print_time:
        print("Estimated print time:", a.estimated_print_time)
    if a.filament_used:
        print("Filament used:", a.filament_used)


def print_report(findings: List[Finding]):
    order = {"FAIL": 0, "WARN": 1, "PASS": 2, "INFO": 3}
    print("\n=== PRUSA XL READINESS REPORT ===")
    for f in sorted(findings, key=lambda x: order.get(x.level, 9)):
        print(f"[{f.level:4}] {f.category:12} {f.message}")

    status = overall_status(findings)
    print("\n" + "=" * 64)
    print("FINAL STATUS:", status)
    print("=" * 64)

    if status == "NOT READY":
        print("Fix the FAIL items before starting the print.")
    elif status == "READY WITH WARNINGS":
        print("No blocking failure was detected, but review the WARN items first.")
    else:
        print("All configured readiness checks passed.")


def save_report(
    output: str,
    gcode: Optional[GCodeAnalysis],
    checklist: ManualChecklist,
    findings: List[Finding],
    live: Optional[Dict[str, Any]],
):
    payload = {
        "overall_status": overall_status(findings),
        "gcode": asdict(gcode) if gcode else None,
        "manual_checklist": asdict(checklist),
        "findings": [asdict(f) for f in findings],
        "prusalink": live,
    }
    Path(output).write_text(json.dumps(payload, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Prusa XL calibration / pre-print readiness agent (MVP)"
    )
    parser.add_argument("--gcode", help="Path to a PrusaSlicer .gcode file")
    parser.add_argument("--host", help="PrusaLink hostname/IP, e.g. 192.168.1.50 or prusa-xl.local")
    parser.add_argument("--user", default="maker", help="PrusaLink username (default: maker)")
    parser.add_argument("--password", help="PrusaLink password. If omitted, you will be prompted.")
    parser.add_argument("--report", default="prusa_xl_report.json", help="JSON report output path")
    args = parser.parse_args()

    print("=" * 64)
    print(" PRUSA XL CALIBRATION / PRE-PRINT AGENT - MVP")
    print(" READ-ONLY PRUSALINK MODE: no heating, motion, or print start")
    print("=" * 64)

    gcode_analysis = None
    gcode_path = args.gcode

    if not gcode_path:
        entered = input("\nG-code path (press Enter to skip): ").strip().strip('"')
        if entered:
            gcode_path = entered

    if gcode_path:
        try:
            gcode_analysis = analyze_gcode(gcode_path)
            print_gcode_summary(gcode_analysis)
        except Exception as exc:
            print(f"\n[WARN] G-code analysis failed: {exc}")

    live = None
    host = args.host
    if not host:
        if yes_no("\nConnect to PrusaLink for LIVE READ-ONLY status?", default=False):
            host = input("Prusa XL IP/hostname: ").strip()

    if host:
        if requests is None:
            print("\n[WARN] requests is not installed. Run: pip install requests")
        else:
            import getpass
            password = args.password or getpass.getpass("PrusaLink password: ")
            try:
                print("\nReading PrusaLink...")
                client = PrusaLinkClient(host, args.user, password)
                live = client.snapshot()
                print(json.dumps(live, indent=2))
            except Exception as exc:
                live = {"connection": {"error": f"{type(exc).__name__}: {exc}"}}
                print(f"[WARN] PrusaLink connection failed: {exc}")

    checklist = collect_checklist()
    findings = evaluate(gcode_analysis, checklist, live)
    print_report(findings)
    save_report(args.report, gcode_analysis, checklist, findings, live)
    print(f"\nReport saved to: {Path(args.report).resolve()}")


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------------
# AGENT HELPERS (added): build a checklist from a dict instead of input()
# ---------------------------------------------------------------------

def checklist_from_dict(answers: Dict[str, Any]) -> ManualChecklist:
    """Anything the user has not confirmed counts as False (unconfirmed)."""
    from dataclasses import fields
    kwargs = {f.name: bool(answers.get(f.name, False)) for f in fields(ManualChecklist)}
    return ManualChecklist(**kwargs)
