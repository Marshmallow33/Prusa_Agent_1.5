"""PrusaLink connection: status, storage, upload, start. Raises PrinterError on problems."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict
from urllib.parse import quote

import requests
from requests.auth import HTTPDigestAuth

STARTABLE = {"IDLE", "READY"}  # states where sending a new job is OK


class PrinterError(Exception):
    pass


class Printer:
    def __init__(self, host: str, user: str, password: str):
        if not host:
            raise PrinterError("No printer address (set PRUSALINK_HOST).")
        if not host.startswith(("http://", "https://")):
            host = "http://" + host
        self.base = host.rstrip("/")
        self.auth = HTTPDigestAuth(user, password)

    def _req(self, method: str, path: str, **kw) -> requests.Response:
        try:
            r = requests.request(method, self.base + path, auth=self.auth,
                                 timeout=kw.pop("timeout", 10), **kw)
        except requests.RequestException as e:
            raise PrinterError(f"Can't reach the printer at {self.base}: {e}")
        if r.status_code == 401:
            raise PrinterError("Printer rejected the login (401). Check PrusaLink user/password.")
        return r

    def status(self) -> Dict[str, Any]:
        r = self._req("GET", "/api/v1/status")
        r.raise_for_status()
        return r.json()

    def state(self) -> str:
        return self.status()["printer"]["state"]

    def storage(self) -> str:
        r = self._req("GET", "/api/v1/storage")
        r.raise_for_status()
        items = [s for s in r.json().get("storage_list", [])
                 if s.get("available") and not s.get("read_only")]
        if not items:
            raise PrinterError("No writable storage on the printer (USB drive inserted?).")
        items.sort(key=lambda s: s.get("type") != "USB")
        return items[0]["name"]

    def upload(self, path: Path, storage: str) -> str:
        name = quote(Path(path).name)
        with Path(path).open("rb") as f:
            r = self._req("PUT", f"/api/v1/files/{storage}/{name}", data=f, timeout=600,
                          headers={"Content-Type": "application/octet-stream",
                                   "Overwrite": "?1", "Print-After-Upload": "?0"})
        if r.status_code == 409:
            raise PrinterError("409 Conflict: printer busy or file in use.")
        if r.status_code != 201:
            raise PrinterError(f"Upload failed: HTTP {r.status_code} {r.text[:200]}")
        return name

    def start(self, storage: str, name: str) -> None:
        r = self._req("POST", f"/api/v1/files/{storage}/{name}")
        if r.status_code != 204:
            raise PrinterError(f"Start failed: HTTP {r.status_code} (409 = a job is already running)")
