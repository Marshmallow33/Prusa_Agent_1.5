"""Tools the LLM may call. The LLM decides WHEN; these functions do the facts.

Safety model: the LLM can read, analyze and UPLOAD, but start_print is gated in
CODE (not by the prompt): it needs a non-failing readiness report for the same
file, an idle printer, and a human confirmation via `confirm_start`.
"""
from __future__ import annotations

import os
from pathlib import Path
from dataclasses import asdict
from typing import Any, Callable, Dict

from . import kb
from .checks import (
    MATERIALS, Finding, PrusaLinkClient, analyze_gcode, checklist_from_dict, evaluate,
    normalize_material, overall_status,
)
from .printer import STARTABLE, Printer

# ---- session state + human gate -------------------------------------
SESSION: Dict[str, Any] = {"report_for": None, "overall": None, "uploaded_path": None,
                           "storage": None, "name": None}


def reset_session() -> None:
    for k in SESSION:
        SESSION[k] = None


def _deny(_summary: str) -> bool:  # default: nobody confirmed -> nothing starts
    return False


# The CLI replaces this with a function that asks the human to type PRINT.
confirm_start: Callable[[str], bool] = _deny


def _printer() -> Printer:
    return Printer(os.getenv("PRUSALINK_HOST", ""), os.getenv("PRUSALINK_USER", "maker"),
                   os.getenv("PRUSALINK_PASSWORD", ""))

# Conservative starting points only. PrusaSlicer's own XL filament profile wins.
SLICER_PRESETS = {
    "draft":    {"layer_height_mm": 0.30, "perimeters": 2, "fill_density": "10-15%"},
    "standard": {"layer_height_mm": 0.20, "perimeters": 2, "fill_density": "15%"},
    "quality":  {"layer_height_mm": 0.15, "perimeters": 3, "fill_density": "15-20%"},
    "strong":   {"layer_height_mm": 0.20, "perimeters": 4, "fill_density": "30-40%"},
}


def tool_analyze_gcode(path: str) -> Dict[str, Any]:
    a = analyze_gcode(path)
    d = asdict(a)
    d.pop("config", None)  # hundreds of keys; too big for a small model's context
    return d


def tool_readiness_report(gcode_path: str = "", answers: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """answers: ManualChecklist field names -> true/false, from what the USER told us.
    Unanswered items count as unconfirmed (so they FAIL/WARN, never silently pass)."""
    g = analyze_gcode(gcode_path) if gcode_path else None
    live = None
    if os.getenv("PRUSALINK_HOST"):
        live = tool_printer_status()
    findings = evaluate(g, checklist_from_dict(answers or {}), live)
    if live:
        st = ((live.get("status") or {}).get("printer") or {}).get("state")
        if st and st not in STARTABLE:
            findings.append(Finding("FAIL", "Printer", f"Printer state is {st}, not IDLE/READY."))
    if g and g.printer_model and "XL" not in g.printer_model.upper():
        findings.append(Finding("FAIL", "G-code", f"File was sliced for '{g.printer_model}', not an XL."))
    SESSION["report_for"] = str(Path(gcode_path).resolve()) if gcode_path else None
    SESSION["overall"] = overall_status(findings)
    return {
        "overall": overall_status(findings),
        "findings": [asdict(f) for f in findings if f.level in ("FAIL", "WARN")],
        "passed_count": sum(f.level == "PASS" for f in findings),
    }


def tool_printer_status() -> Dict[str, Any]:
    host = os.getenv("PRUSALINK_HOST")
    if not host:
        return {"error": "PRUSALINK_HOST not set; printer status unavailable."}
    return PrusaLinkClient(host, os.getenv("PRUSALINK_USER", "maker"),
                           os.getenv("PRUSALINK_PASSWORD", "")).snapshot()


def tool_upload_gcode(path: str) -> Dict[str, Any]:
    """Copy the file to the printer's storage. Does NOT start anything."""
    p = Path(path)
    if not p.is_file():
        return {"error": f"File not found: {path}"}
    pr = _printer()
    storage = pr.storage()
    name = pr.upload(p, storage)
    SESSION.update(uploaded_path=str(p.resolve()), storage=storage, name=name)
    return {"uploaded": name, "storage": storage,
            "next": "File is on the printer. Run readiness_report if not done, then start_print."}


def tool_start_print() -> Dict[str, Any]:
    """Start the uploaded file. Refuses unless every gate passes."""
    if not SESSION["name"]:
        return {"refused": "Nothing uploaded yet. Call upload_gcode first."}
    if SESSION["uploaded_path"] != SESSION["report_for"]:
        return {"refused": "No readiness_report for the uploaded file. Run readiness_report with its gcode_path first."}
    if SESSION["overall"] == "NOT READY":
        return {"refused": "Readiness report is NOT READY. Fix the FAIL items and re-run readiness_report."}
    pr = _printer()
    state = pr.state()
    if state not in STARTABLE:
        return {"refused": f"Printer state is {state}, not IDLE/READY."}
    if not confirm_start(f"Start '{SESSION['name']}' now? Readiness: {SESSION['overall']}"):
        return {"refused": "The human did not confirm. Not started."}
    pr.start(SESSION["storage"], SESSION["name"])
    return {"started": SESSION["name"]}


def tool_material_info(material: str) -> Dict[str, Any]:
    key = normalize_material(material)
    info = MATERIALS.get(key)
    if not info:
        return {"error": f"Unknown material '{material}'. Known: {sorted(MATERIALS)}"}
    return {"material": key, **info, "note": "Broad ranges; the exact PrusaSlicer profile is authoritative."}


def tool_suggest_slicer_params(material: str, goal: str = "standard", nozzle_mm: float = 0.4) -> Dict[str, Any]:
    m = tool_material_info(material)
    if "error" in m:
        return m
    preset = SLICER_PRESETS.get(goal.lower())
    if not preset:
        return {"error": f"goal must be one of {sorted(SLICER_PRESETS)}"}
    lo, hi = m["nozzle_range"]
    blo, bhi = m["bed_range"]
    return {
        **preset,
        "nozzle_temp_range_c": [lo, hi],
        "bed_temp_range_c": [blo, bhi],
        "layer_height_ok_for_nozzle": preset["layer_height_mm"] <= 0.75 * nozzle_mm,
        "note": "Starting point. Start from the Prusa XL profile for this filament in PrusaSlicer and adjust.",
    }


def tool_search_knowledge(query: str) -> Dict[str, Any]:
    hits = kb.search(query)
    return {"results": [{"source": n, "text": t[:1200]} for n, t in hits]} if hits else {"results": []}


# name -> (function, description for the LLM)
TOOLS: Dict[str, tuple[Callable[..., Any], str]] = {
    "analyze_gcode": (tool_analyze_gcode,
        'args: {"path": "<.gcode file>"}. Parses PrusaSlicer G-code: printer, nozzle, filaments, temps, tools, supports.'),
    "readiness_report": (tool_readiness_report,
        'args: {"gcode_path": "<optional>", "answers": {"nozzle_clean": true, ...}}. PASS/WARN/FAIL pre-print check. '
        "Valid answer keys: nozzle_clean, sheet_clean, sheet_seated, nothing_under_sheet, build_area_clear, fans_clear, "
        "tool_docks_clear, filament_loaded_correctly, enough_filament, filament_dry, selftest_passed, loadcell_ok, "
        "phase_stepping_ok, tool_offset_ok, belts_look_ok, nozzle_not_damaged, hardened_nozzle_installed, enclosure_available. "
        "Only include keys the user actually confirmed."),
    "upload_gcode": (tool_upload_gcode,
        'args: {"path": "<.gcode file>"}. Uploads the file to the printer. Does not start it.'),
    "start_print": (tool_start_print,
        "args: {}. Starts the uploaded file. Only works after readiness_report (not NOT READY) and "
        "upload_gcode for the same file; the human is asked to confirm. Never call it unless the user asked to print."),
    "printer_status": (tool_printer_status,
        "args: {}. Live read-only status from the printer over PrusaLink."),
    "material_info": (tool_material_info,
        'args: {"material": "PETG"}. Temperature ranges and handling flags.'),
    "suggest_slicer_params": (tool_suggest_slicer_params,
        'args: {"material": "PLA", "goal": "draft|standard|quality|strong", "nozzle_mm": 0.4}.'),
    "search_knowledge": (tool_search_knowledge,
        'args: {"query": "..."}. Searches the team knowledge base (maintenance, calibration, troubleshooting).'),
}


def describe_tools() -> str:
    return "\n".join(f"- {n}: {d}" for n, (_, d) in TOOLS.items())
