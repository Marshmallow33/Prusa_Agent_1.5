"""The agent loop: LLM decides -> we run a tool -> result goes back -> repeat.

Tool calling uses a plain JSON protocol in the prompt instead of any vendor's
function-calling API, so the SAME loop works with Phi-3 Mini (Ollama), Gemini,
and whatever IntelliMake gives us.
"""
from __future__ import annotations

import json
import re
from typing import Callable, List, Optional

from .llm import LLM, Message
from .tools import TOOLS, describe_tools

SYSTEM = """You are the Prusa XL Setup Assistant, helping users prepare a Prusa XL multi-tool 3D printer.

You may call tools. To call one, reply with ONLY a JSON object:
{{"tool": "<name>", "args": {{...}}}}
When you have what you need, reply with ONLY:
{{"final": "<answer for the user>"}}

Tools:
{tools}

Rules:
- Never invent printer facts, temperatures, or G-code contents: call a tool.
- For a pre-print check, ask the user about physical items you cannot see (nozzle, sheet, filament) and only pass items they confirmed.
- To print: analyze_gcode, ask the user the physical questions, readiness_report, upload_gcode, then start_print only if the user asks. The code asks the human to confirm; never claim a print started unless start_print returned started.
- Put FAIL items first, then WARN items, in plain language. Keep answers short.
- If a tool returns an error, tell the user what is missing.
"""

_JSON = re.compile(r"\{.*\}", re.S)


def parse_reply(text: str) -> Optional[dict]:
    """Pull the first JSON object out of a (possibly chatty) model reply."""
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    for m in [text] + _JSON.findall(text):
        try:
            obj = json.loads(m)
            if isinstance(obj, dict):
                return obj
        except json.JSONDecodeError:
            continue
    return None


class Agent:
    def __init__(self, llm: LLM, max_steps: int = 6, log: Callable[[str], None] = lambda s: None):
        self.llm, self.max_steps, self.log = llm, max_steps, log
        self.system = SYSTEM.format(tools=describe_tools())
        self.history: List[Message] = []

    def ask(self, user_text: str) -> str:
        self.history.append({"role": "user", "content": user_text})
        for step in range(self.max_steps):
            raw = self.llm.chat(self.system, self.history)
            self.history.append({"role": "assistant", "content": raw})
            obj = parse_reply(raw)

            if obj is None:  # model ignored the format; treat as a plain answer
                return raw.strip()
            if "final" in obj:
                return str(obj["final"])

            name, args = obj.get("tool"), obj.get("args") or {}
            self.log(f"[tool] {name}({args})")
            if name not in TOOLS:
                result = {"error": f"unknown tool '{name}'", "valid": list(TOOLS)}
            else:
                try:
                    result = TOOLS[name][0](**args)
                except Exception as e:  # report to the model; let it recover
                    result = {"error": f"{type(e).__name__}: {e}"}
            self.history.append({"role": "user", "content": "TOOL_RESULT " + json.dumps(result, default=str)})
        return "I couldn't finish within the step limit. Try a more specific question."
