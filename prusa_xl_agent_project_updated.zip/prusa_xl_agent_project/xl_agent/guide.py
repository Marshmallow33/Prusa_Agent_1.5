"""Guided pre-print walkthrough:   python -m xl_agent.guide part.gcode

Python controls the ORDER and the SAFETY (so even a weak local model can't skip
steps). The LLM is used to explain things in plain language and answer questions.
If the LLM is unreachable, the walkthrough still works without it.
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from . import tools
from .agent import Agent
from .checks import MATERIALS, analyze_gcode, is_abrasive, normalize_material, print_gcode_summary
from .printer import Printer, PrinterError

# (checklist key, question, hint). Hints are general; the lab's own procedure wins.
QUESTIONS: List[Tuple[str, str, str]] = [
    ("build_area_clear", "Is the build area clear of tools, old parts and debris?", "Look at the whole bed and the tool-change path."),
    ("tool_docks_clear", "Are the tool docks / toolchanger path clear?", "Nothing should block the tools parking in their docks."),
    ("sheet_seated", "Is the print sheet seated flat?", "It should sit flush with no gaps at the edges."),
    ("nothing_under_sheet", "Is there nothing trapped under the sheet?", "Lift a corner and look for debris or leftover plastic."),
    ("sheet_clean", "Is the sheet clean (no fingerprints, grease, residue)?", "Wipe with isopropyl alcohol if unsure, and don't touch it afterwards."),
    ("nozzle_clean", "Is each nozzle you'll use free of blobs or residue?", "Only clean a nozzle when the lab says it's safe: hot nozzles burn."),
    ("nozzle_not_damaged", "Do the nozzles look undamaged and properly installed?", "No bends, no wobble."),
    ("fans_clear", "Do the fans look clear and unobstructed?", "No loose filament or dust blocking them."),
    ("belts_look_ok", "Do belts and mechanics look normal?", "No visible loose or damaged belts."),
    ("filament_loaded_correctly", "Is the correct filament loaded in each tool the file uses?", "{filament_hint}"),
    ("enough_filament", "Is there enough filament on the spool for this job?", "{use_hint}"),
    ("filament_dry", "Is the filament dry (no popping, bubbling or stringing in recent prints)?", "Moisture-sensitive material was detected in this file."),
    ("hardened_nozzle_installed", "Is a hardened / wear-resistant nozzle installed?", "Abrasive filament was detected in this file."),
    ("selftest_passed", "Has the printer's self-test passed (and been run recently)?", "Ask lab staff if you don't know."),
    ("loadcell_ok", "Is the loadcell test known to be good?", "Part of the XL self-test."),
    ("phase_stepping_ok", "Is Phase Stepping calibration known to be good?", "Answer n if unsure and ask lab staff."),
    ("tool_offset_ok", "Is tool-offset calibration done for the tools you'll use?", "Matters most on multi-tool prints."),
]


def _relevant(g) -> List[Tuple[str, str, str]]:
    mats = [normalize_material(m) for m in g.filament_types]
    wet = any(MATERIALS.get(m, {}).get("moisture_sensitive") for m in mats)
    abr = any(is_abrasive(m) for m in g.filament_types)
    fh = ("Slots needed: " + ", ".join(f"T{t} = {g.filament_types[t] if t < len(g.filament_types) else '?'}"
                                        for t in (g.tools_used or [0])))
    uh = f"The slicer estimated: {g.filament_used}" if g.filament_used else "Check the spool isn't nearly empty."
    out = []
    for key, q, hint in QUESTIONS:
        if key == "filament_dry" and not wet:
            continue
        if key == "hardened_nozzle_installed" and not abr:
            continue
        out.append((key, q, hint.format(filament_hint=fh, use_hint=uh)))
    return out


def ask_yn(question: str, hint: str = "", ask: Callable[[str], str] = input) -> Optional[bool]:
    """y -> True, n -> False, '?' -> None (don't know = unconfirmed)."""
    print(f"\n{question}" + (f"\n   hint: {hint}" if hint else ""))
    while True:
        v = ask("   [y / n / ? = not sure] > ").strip().lower()
        if v in {"y", "yes"}:
            return True
        if v in {"n", "no"}:
            return False
        if v in {"?", "idk", "not sure"}:
            return None
        print("   Please type y, n or ?")


NARRATE = ("You are a calm 3D-printing coach for a beginner using a Prusa XL. Explain the information "
           "below in plain language in under 120 words. FAIL items first. Do not invent facts.")


def narrate(llm, text: str) -> Optional[str]:
    try:
        return llm.chat(NARRATE, [{"role": "user", "content": text}]).strip()
    except Exception as e:  # LLM down is not fatal
        print(f"   (AI explanation unavailable: {type(e).__name__})")
        return None


def run(gcode: str, llm=None, ask: Callable[[str], str] = input) -> str:
    """Returns one of: 'started', 'uploaded', 'not_ready', 'offline', 'stopped'."""
    tools.reset_session()
    path = Path(gcode)
    if not path.is_file():
        raise SystemExit(f"File not found: {path}")

    # ---- Step 1: the file
    print("\n=== STEP 1/5: Reading your G-code ===")
    g = analyze_gcode(str(path))
    print_gcode_summary(g)
    if llm:
        brief = narrate(llm, "G-code facts: " + json.dumps(tools.tool_analyze_gcode(str(path))))
        if brief:
            print("\nCoach:", brief)

    # ---- Step 2: the printer
    print("\n=== STEP 2/5: Checking the printer ===")
    connected = False
    try:
        st = tools._printer().status()
        p = st.get("printer", {})
        print(f"State: {p.get('state')}   Nozzle: {p.get('temp_nozzle', '?')}°C   Bed: {p.get('temp_bed', '?')}°C")
        connected = True
    except PrinterError as e:
        print(f"Can't talk to the printer: {e}\nContinuing OFFLINE (you can still do the checklist; no upload).")

    # ---- Step 3: physical checklist
    print("\n=== STEP 3/5: Walk-around checklist (answer from what you can see) ===")
    answers: Dict[str, bool] = {k: True for k, _, _ in QUESTIONS}  # skipped-as-irrelevant counts as OK
    for key, q, hint in _relevant(g):
        answers[key] = bool(ask_yn(q, hint, ask))
    answers["enclosure_available"] = False

    # ---- Step 4: verdict
    print("\n=== STEP 4/5: Readiness verdict ===")
    rep = tools.tool_readiness_report(str(path), answers)
    print("RESULT:", rep["overall"])
    for f in rep["findings"]:
        print(f"  [{f['level']}] {f['category']}: {f['message']}")
    if llm:
        tip = narrate(llm, "Readiness result: " + json.dumps(rep))
        if tip:
            print("\nCoach:", tip)
        qa = Agent(llm)
        print("\nAsk me anything about this print (or press Enter to continue).")
        while True:
            q = ask("you> ").strip()
            if not q:
                break
            print("Coach:", qa.ask(q))

    if rep["overall"] == "NOT READY":
        print("\nNot ready. Fix the FAIL items, then run this again.")
        return "not_ready"
    if not connected:
        print("\nPrinter not reachable: copy the file on a USB stick and start it from the printer screen.")
        return "offline"

    # ---- Step 5: upload + start
    print("\n=== STEP 5/5: Send to printer ===")
    if ask("Upload the file to the printer now? [y/N] ").strip().lower() != "y":
        return "stopped"
    try:
        info = tools.tool_upload_gcode(str(path))
    except PrinterError as e:
        print(f"Upload failed: {e}")
        return "stopped"
    print(f"Uploaded as {info['uploaded']} on '{info['storage']}'.")
    print("\nStand at the printer. You can start it from the screen (Print > pick the file),")
    print("or start it from here.")
    tools.confirm_start = lambda summary: ask(f"{summary}\nType PRINT to start: ").strip() == "PRINT"
    if ask("Start from here? [y/N] ").strip().lower() != "y":
        return "uploaded"
    res = tools.tool_start_print()
    print(res.get("started") and "Print started. Watch the first layer closely." or f"Not started: {res}")
    return "started" if res.get("started") else "uploaded"


def main():
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass
    ap = argparse.ArgumentParser(description="Guided Prusa XL pre-print walkthrough")
    ap.add_argument("gcode")
    ap.add_argument("--no-ai", action="store_true", help="skip the language model")
    a = ap.parse_args()
    if os.getenv("PRUSALINK_HOST") and not os.getenv("PRUSALINK_PASSWORD"):
        os.environ["PRUSALINK_PASSWORD"] = getpass.getpass("PrusaLink password: ")
    llm = None
    if not a.no_ai:
        from .llm import load_llm
        try:
            llm = load_llm()
            print(f"AI: {llm.name}")
        except SystemExit as e:
            print(f"(No AI: {e}). Continuing without it.")
    run(a.gcode, llm)


if __name__ == "__main__":
    main()
