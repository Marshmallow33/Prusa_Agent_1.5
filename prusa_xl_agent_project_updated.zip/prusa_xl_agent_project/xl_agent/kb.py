"""Tiny knowledge base: markdown files in ./knowledge, keyword-scored retrieval.

Julian (docs/KB lead) just adds .md files; no code changes needed. Upgrade to
embeddings later if keyword search stops being good enough.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List, Tuple

KB_DIR = Path(__file__).resolve().parent.parent / "knowledge"


def _chunks() -> List[Tuple[str, str]]:
    out = []
    for f in sorted(KB_DIR.glob("*.md")):
        for part in re.split(r"\n(?=#{1,3} )", f.read_text(encoding="utf-8")):
            if part.strip():
                out.append((f.name, part.strip()))
    return out


def search(query: str, k: int = 3) -> List[Tuple[str, str]]:
    words = {w for w in re.findall(r"[a-z0-9]+", query.lower()) if len(w) > 2}
    scored = []
    for name, text in _chunks():
        low = text.lower()
        score = sum(low.count(w) for w in words)
        if score:
            scored.append((score, name, text))
    scored.sort(reverse=True)
    return [(n, t) for _, n, t in scored[:k]]
