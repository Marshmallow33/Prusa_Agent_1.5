"""Tiny fake PrusaLink for testing print_gcode.py:  python tests/fake_prusalink.py [STATE]"""
import json, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
STATE = sys.argv[1] if len(sys.argv) > 1 else "IDLE"
class H(BaseHTTPRequestHandler):
    def _send(self, code, body=None):
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers()
        if body is not None: self.wfile.write(json.dumps(body).encode())
    def do_GET(self):
        if self.path == "/api/v1/status": self._send(200, {"printer": {"state": STATE, "temp_nozzle": 24.0, "temp_bed": 23.5}})
        elif self.path == "/api/version": self._send(200, {"api": "2.0.0", "server": "fake"})
        elif self.path == "/api/v1/info": self._send(200, {"name": "fake-xl"})
        elif self.path == "/api/v1/storage": self._send(200, {"storage_list": [{"name": "usb", "type": "USB", "available": True, "read_only": False, "path": "/usb"}]})
        else: self._send(404)
    def do_PUT(self):
        n = int(self.headers.get("Content-Length", 0)); data = self.rfile.read(n)
        print("FAKE: PUT", self.path, n, "bytes", dict(Overwrite=self.headers.get("Overwrite"), PAU=self.headers.get("Print-After-Upload")), flush=True)
        self._send(201)
    def do_POST(self): print("FAKE: START", self.path, flush=True); self._send(204)
    def log_message(self, *a): pass
HTTPServer(("127.0.0.1", 8765), H).serve_forever()
