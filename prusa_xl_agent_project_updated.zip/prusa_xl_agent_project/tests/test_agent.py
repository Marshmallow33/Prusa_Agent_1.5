"""Offline tests: a scripted fake LLM drives the real agent loop and real tools.
Run:  python -m pytest -q   (or python tests/test_agent.py)
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from xl_agent.agent import Agent, parse_reply  # noqa: E402

SAMPLE = str(Path(__file__).resolve().parent.parent / "samples" / "demo_multitool.gcode")


class ScriptedLLM:
    name = "scripted"

    def __init__(self, replies):
        self.replies, self.seen = list(replies), []

    def chat(self, system, messages):
        self.seen.append(messages[-1]["content"])
        return self.replies.pop(0)


def test_parse_reply_handles_fences_and_chatter():
    assert parse_reply('```json\n{"final": "hi"}\n```') == {"final": "hi"}
    assert parse_reply('Sure! {"tool": "material_info", "args": {"material": "PLA"}} ok')["tool"] == "material_info"
    assert parse_reply("no json here") is None


def test_agent_calls_tool_then_answers():
    llm = ScriptedLLM([
        json.dumps({"tool": "analyze_gcode", "args": {"path": SAMPLE}}),
        json.dumps({"final": "Multi-tool PETG/PLA job."}),
    ])
    out = Agent(llm).ask("check my gcode")
    assert out == "Multi-tool PETG/PLA job."
    result = json.loads(llm.seen[1].removeprefix("TOOL_RESULT "))
    assert result["filament_types"] == ["PETG", "PLA"] and result["tools_used"] == [0, 1]


def test_unconfirmed_items_fail_not_pass():
    llm = ScriptedLLM([
        json.dumps({"tool": "readiness_report", "args": {"gcode_path": SAMPLE, "answers": {"nozzle_clean": True}}}),
        json.dumps({"final": "done"}),
    ])
    Agent(llm).ask("am I ready?")
    result = json.loads(llm.seen[1].removeprefix("TOOL_RESULT "))
    assert result["overall"] == "NOT READY"


def test_bad_tool_and_bad_args_dont_crash():
    llm = ScriptedLLM([
        json.dumps({"tool": "format_disk", "args": {}}),
        json.dumps({"tool": "material_info", "args": {"wrong": 1}}),
        json.dumps({"final": "ok"}),
    ])
    assert Agent(llm).ask("print it") == "ok"
    assert "unknown tool" in llm.seen[1]
    assert "error" in llm.seen[2]


def test_step_limit():
    llm = ScriptedLLM([json.dumps({"tool": "material_info", "args": {"material": "PLA"}})] * 10)
    assert "step limit" in Agent(llm, max_steps=3).ask("loop")


if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-q"]))
