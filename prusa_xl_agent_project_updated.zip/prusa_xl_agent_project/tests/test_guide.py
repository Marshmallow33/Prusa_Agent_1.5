"""End-to-end: guided flow vs fake PrusaLink (real HTTP), scripted answers, scripted LLM."""
import os, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
SAMPLE = str(ROOT / "samples" / "demo_multitool.gcode")


def fake(state):
    p = subprocess.Popen([sys.executable, str(ROOT / "tests" / "fake_prusalink.py"), state],
                         stdout=subprocess.PIPE, text=True)
    time.sleep(1)
    return p


def scripted(answers):
    it = iter(answers)
    return lambda prompt="": next(it)


def run_flow(state, answers):
    from xl_agent import guide, tools
    os.environ.update(PRUSALINK_HOST="127.0.0.1:8765", PRUSALINK_PASSWORD="x")
    p = fake(state)
    try:
        return guide.run(SAMPLE, llm=None, ask=scripted(answers)), p
    finally:
        p.terminate()
        p.wait()


def test_full_happy_path_starts_only_after_human_PRINT():
    from xl_agent import guide
    from xl_agent.checks import analyze_gcode
    n_q = len(guide._relevant(analyze_gcode(SAMPLE)))
    out, p = run_flow("IDLE", ["y"] * n_q + ["y", "y", "PRINT"])
    assert out == "started"


def test_human_declines_start():
    from xl_agent import guide
    from xl_agent.checks import analyze_gcode
    n_q = len(guide._relevant(analyze_gcode(SAMPLE)))
    out, _ = run_flow("IDLE", ["y"] * n_q + ["y", "y", "nope"])
    assert out == "uploaded"


def test_any_no_on_critical_item_blocks():
    from xl_agent import guide
    from xl_agent.checks import analyze_gcode
    n_q = len(guide._relevant(analyze_gcode(SAMPLE)))
    out, _ = run_flow("IDLE", ["n"] + ["y"] * (n_q - 1))
    assert out == "not_ready"


def test_busy_printer_blocks():
    from xl_agent import guide
    from xl_agent.checks import analyze_gcode
    n_q = len(guide._relevant(analyze_gcode(SAMPLE)))
    out, _ = run_flow("PRINTING", ["y"] * n_q)
    assert out == "not_ready"


def test_start_print_tool_refuses_without_gates():
    from xl_agent import tools
    tools.reset_session()
    assert "refused" in tools.tool_start_print()
    tools.SESSION.update(name="a.gcode", uploaded_path="A", report_for="B", overall="READY")
    assert "refused" in tools.tool_start_print()


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
