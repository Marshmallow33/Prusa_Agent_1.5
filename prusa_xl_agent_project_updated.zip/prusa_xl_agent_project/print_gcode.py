"""Basic G-code -> Prusa XL sender (PrusaLink). No AI involved.

    python print_gcode.py my_part.gcode            # check, upload, ask, then start
    python print_gcode.py my_part.gcode --check    # only analyze the file
    python print_gcode.py my_part.gcode --upload-only   # upload, do NOT start

Needs PRUSALINK_HOST / PRUSALINK_USER / PRUSALINK_PASSWORD in .env (or env vars),
or pass --host/--user/--password. It will not start unless the printer is idle
and you type the word PRINT.
"""
from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path

from xl_agent.checks import analyze_gcode, print_gcode_summary
from xl_agent.printer import STARTABLE, Printer, PrinterError

def _main():
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument("gcode")
    ap.add_argument("--check", action="store_true", help="analyze only; do not contact printer")
    ap.add_argument("--upload-only", action="store_true", help="upload but do not start")
    ap.add_argument("--host", default=os.getenv("PRUSALINK_HOST"))
    ap.add_argument("--user", default=os.getenv("PRUSALINK_USER", "maker"))
    ap.add_argument("--password", default=os.getenv("PRUSALINK_PASSWORD"))
    a = ap.parse_args()

    path = Path(a.gcode)
    if not path.is_file():
        sys.exit(f"File not found: {path}")

    # 1. Look inside the file (text .gcode only; .bgcode is binary)
    if path.suffix.lower() == ".bgcode":
        print("Binary G-code (.bgcode): skipping analysis. Export plain .gcode if you want the check.")
    else:
        info = analyze_gcode(str(path))
        print_gcode_summary(info)
        if info.printer_model and "XL" not in info.printer_model.upper():
            sys.exit(f"\nSTOP: this file was sliced for '{info.printer_model}', not a Prusa XL.")
    if a.check:
        return

    # 2. Printer must be reachable and idle
    if not a.host:
        sys.exit("No printer address. Set PRUSALINK_HOST in .env or use --host.")
    printer = Printer(a.host, a.user, a.password or getpass.getpass("PrusaLink password: "))
    try:
        state = printer.state()
    except PrinterError as e:
        sys.exit(str(e))
    print(f"\nPrinter state: {state}")
    if state not in STARTABLE and not a.upload_only:
        sys.exit(f"Printer is {state}, not IDLE/READY. Not sending a print.")

    # 3. Upload
    storage = printer.storage()
    print(f"Uploading to '{storage}' ...")
    name = printer.upload(path, storage)
    print("Uploaded.")
    if a.upload_only:
        print("Done. Start it from the printer's screen: Print > pick the file.")
        return

    # 4. Human confirmation, then start
    print("\nBefore starting: sheet clean + seated, bed clear, filament loaded in the right tool(s), you are standing at the printer.")
    if input("Type PRINT to start: ").strip() != "PRINT":
        print("Not started. The file is on the printer; you can start it from the screen.")
        return
    printer.start(storage, name)
    print("Print started. Watch the first layer.")


def main():
    try:
        _main()
    except PrinterError as e:
        sys.exit(f"Printer error: {e}")


if __name__ == "__main__":
    main()
