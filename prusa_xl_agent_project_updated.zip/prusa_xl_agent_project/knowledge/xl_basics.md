# Prusa XL basics (STARTER NOTES: verify each against help.prusa3d.com and add sources)

## Pre-print checks
Clean the nozzle exterior, wipe the print sheet with isopropyl alcohol, confirm nothing is under the sheet, and confirm the build area and tool docks are clear before starting a print.

## Calibration and self-test
The XL runs a self-test and calibrations (including loadcell and tool offsets) from the printer's Control/Settings menu. Re-run tool-offset calibration after moving or changing tools in a multi-tool job.

## Abrasive filaments
Carbon-fiber, glass-fiber and glow-in-the-dark filaments wear brass nozzles quickly. Use a hardened or wear-resistant nozzle for them.

## Moisture
PETG, ASA, ABS, nylon, PC, TPU and PVA absorb moisture. Wet filament causes stringing, bubbling and rough surfaces. Dry before printing if in doubt.

## Multi-tool prints
Each tool (T0, T1, ...) is a separate printhead. Assign filaments and support extruders in PrusaSlicer, and keep the wipe tower enabled unless you have a reason not to.
