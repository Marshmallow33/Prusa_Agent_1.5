# Prusa XL Setup Agent

PrusaSlicer .gcode -> `xl_agent` (LLM + tools) -> readiness advice. Optional read-only PrusaLink status.

## Run
    pip install -r requirements.txt
    cp .env.example .env        # fill in
    ollama pull phi3:mini       # for local dev
    python -m xl_agent --gcode samples/demo_multitool.gcode -v

Switch model by changing LLM_PROVIDER in .env (ollama / gemini / openai_compat for IntelliMake).

## Layout
- xl_agent/checks.py  original MVP logic (G-code parser, checklist rules, PrusaLink client)
- xl_agent/tools.py   functions the LLM can call (add new ones to TOOLS)
- xl_agent/agent.py   the agent loop
- xl_agent/llm.py     Ollama / Gemini / OpenAI-compatible clients
- xl_agent/kb.py + knowledge/*.md   knowledge base (Julian: add .md files)
- tests/test_agent.py offline tests (no API key needed)

Safety: all tools are read-only. Nothing heats, moves, or starts the printer.

## Basic sender (no AI)
    python print_gcode.py samples/demo_multitool.gcode --check      # analyze only
    python print_gcode.py part.gcode --upload-only                  # upload, start from printer screen
    python print_gcode.py part.gcode                                # upload, confirm, start
Tests: `python tests/fake_prusalink.py` runs a fake printer on 127.0.0.1:8765; point --host at it.

## Guided agent (main entry point)
    python -m xl_agent.guide part.gcode            # walkthrough with AI coach
    python -m xl_agent.guide part.gcode --no-ai    # same walkthrough, no model needed
    python -m xl_agent --gcode part.gcode -v       # free-form chat; the AI chooses tools
Steps: read G-code -> check printer -> walk-around checklist -> verdict -> upload -> (optional) start.
Starting is gated IN CODE: needs a non-failing report for the same file, an IDLE printer,
and you typing PRINT. The AI cannot bypass this.
Tests: python tests/test_guide.py   (starts a fake printer itself)
